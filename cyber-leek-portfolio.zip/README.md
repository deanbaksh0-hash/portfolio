# Cyber Leek Portfolio

Single-file portfolio site (React + Tailwind, pre-built and inlined into `index.html`). No build step, no dependencies.

## Run locally
Open `index.html` in a browser, or serve the folder:

```bash
python3 -m http.server 8000
```

Then visit http://localhost:8000

## Deploy to GitHub Pages
1. Create a new repo on GitHub and push these files (see below).
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to **Deploy from a branch**, branch `main`, folder `/ (root)`.
4. Your site goes live at `https://<your-username>.github.io/<repo-name>/` within a minute or two.

(Optional) The included workflow in `.github/workflows/pages.yml` deploys automatically if you set **Source** to **GitHub Actions** instead.

## Push to GitHub
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```

Also works on Netlify, Vercel, Cloudflare Pages: just point them at this folder, no build command, output directory `.`
